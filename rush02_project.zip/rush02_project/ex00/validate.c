#include "rush02.h"

int	is_valid_number(char *str)
{
	int	i;

	if (!str || str[0] == '\0')
		return (0);
	i = 0;
	while (str[i])
	{
		if (str[i] < '0' || str[i] > '9')
			return (0);
		i++;
	}
	return (1);
}

char	*skip_zeros(char *number)
{
	while (number[0] == '0' && number[1] != '\0')
		number++;
	return (number);
}
