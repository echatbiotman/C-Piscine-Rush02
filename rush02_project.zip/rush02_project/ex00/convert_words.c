#include "rush02.h"

static int	emit_key(t_output *out, char *key)
{
	char	*word;

	word = dict_find(out->dict, key);
	if (!word)
		return (0);
	if (out->print)
	{
		if (!out->first)
			write(1, " ", 1);
		ft_putstr(word);
		out->first = 0;
	}
	return (1);
}

static int	emit_small(t_output *out, int number)
{
	char	key[4];
	int		i;

	if (number == 0)
		return (emit_key(out, "0"));
	i = 0;
	if (number >= 100)
		key[i++] = number / 100 + '0';
	if (number >= 10)
		key[i++] = number / 10 % 10 + '0';
	key[i++] = number % 10 + '0';
	key[i] = '\0';
	return (emit_key(out, key));
}

int	convert_under_100(int number, t_output *out)
{
	int	tens;

	if (number < 20)
		return (emit_small(out, number));
	tens = number / 10 * 10;
	if (!emit_small(out, tens))
		return (0);
	if (number % 10 != 0 && !emit_small(out, number % 10))
		return (0);
	return (1);
}

int	convert_group(int number, t_output *out)
{
	if (number >= 100)
	{
		if (!emit_small(out, number / 100))
			return (0);
		if (!emit_key(out, "100"))
			return (0);
		number %= 100;
	}
	if (number > 0 && !convert_under_100(number, out))
		return (0);
	return (1);
}

int	emit_scale(t_output *out, int group_index)
{
	char	*key;
	int		zeros;
	int		i;
	int		ok;

	if (group_index == 0)
		return (1);
	zeros = group_index * 3;
	key = malloc(zeros + 2);
	if (!key)
		return (0);
	key[0] = '1';
	i = 1;
	while (i <= zeros)
		key[i++] = '0';
	key[i] = '\0';
	ok = emit_key(out, key);
	free(key);
	return (ok);
}
