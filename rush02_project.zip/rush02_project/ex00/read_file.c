#include "rush02.h"

static int	get_file_size(char *path)
{
	char	buffer[1024];
	int		fd;
	int		bytes;
	int		total;

	fd = open(path, O_RDONLY);
	if (fd < 0)
		return (-1);
	total = 0;
	bytes = read(fd, buffer, 1024);
	while (bytes > 0)
	{
		total += bytes;
		bytes = read(fd, buffer, 1024);
	}
	close(fd);
	if (bytes < 0)
		return (-1);
	return (total);
}

static int	fill_file(char *path, char *buffer, int size)
{
	int	fd;
	int	bytes;
	int	total;

	fd = open(path, O_RDONLY);
	if (fd < 0)
		return (0);
	total = 0;
	while (total < size)
	{
		bytes = read(fd, buffer + total, size - total);
		if (bytes <= 0)
			break ;
		total += bytes;
	}
	close(fd);
	return (total == size);
}

char	*read_file(char *path)
{
	char	*buffer;
	int		size;

	size = get_file_size(path);
	if (size < 0)
		return (0);
	buffer = malloc(size + 1);
	if (!buffer)
		return (0);
	if (!fill_file(path, buffer, size))
	{
		free(buffer);
		return (0);
	}
	buffer[size] = '\0';
	return (buffer);
}
