#include "rush02.h"

int	store_entry(char *buffer, t_bounds *b, t_dict *dict)
{
	char	*key;
	char	*value;

	key = dup_range(buffer, b->key_start, b->key_end);
	if (!key)
		return (0);
	value = dup_range(buffer, b->value_start, b->value_end);
	if (!value || key_exists(dict, key))
	{
		free(key);
		free(value);
		return (0);
	}
	dict->entries[dict->size].key = key;
	dict->entries[dict->size].value = value;
	dict->size++;
	return (1);
}
