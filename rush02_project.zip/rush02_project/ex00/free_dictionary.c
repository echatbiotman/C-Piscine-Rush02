#include "rush02.h"

void	free_dictionary(t_dict *dict)
{
	int	i;

	i = 0;
	while (i < dict->size)
	{
		free(dict->entries[i].key);
		free(dict->entries[i].value);
		i++;
	}
	free(dict->entries);
	dict->entries = 0;
	dict->size = 0;
}
