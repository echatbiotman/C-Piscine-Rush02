#ifndef RUSH02_H
# define RUSH02_H

# include <unistd.h>
# include <stdlib.h>
# include <fcntl.h>

typedef struct s_entry
{
	char	*key;
	char	*value;
}t_entry;

typedef struct s_dict
{
	t_entry	*entries;
	int		size;
}t_dict;

typedef struct s_bounds
{
	int	key_start;
	int	key_end;
	int	value_start;
	int	value_end;
}t_bounds;

typedef struct s_output
{
	t_dict	*dict;
	int		first;
	int		print;
}t_output;

int		ft_strlen(char *str);
int		ft_strcmp(char *s1, char *s2);
void	ft_putstr(char *str);
int		is_blank(char c);
char	*dup_range(char *str, int start, int end);
int		line_is_empty(char *str, int start, int end);
int		key_exists(t_dict *dict, char *key);
int		is_valid_number(char *str);
char	*skip_zeros(char *number);
char	*read_file(char *path);
int		store_entry(char *buffer, t_bounds *b, t_dict *dict);
int		parse_dictionary(char *buffer, t_dict *dict);
char	*dict_find(t_dict *dict, char *key);
void	free_dictionary(t_dict *dict);
int		convert_number(char *number, t_dict *dict, int print);

#endif
