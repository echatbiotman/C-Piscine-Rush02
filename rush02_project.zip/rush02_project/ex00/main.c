#include "rush02.h"

static int	load_dictionary(char *path, t_dict *dict)
{
	char	*buffer;
	int		ok;

	buffer = read_file(path);
	if (!buffer)
		return (0);
	ok = parse_dictionary(buffer, dict);
	free(buffer);
	return (ok);
}

static int	print_dict_error(t_dict *dict)
{
	free_dictionary(dict);
	ft_putstr("Dict Error\n");
	return (1);
}

int	main(int argc, char **argv)
{
	char	*path;
	char	*number;
	t_dict	dict;

	if (argc != 2 && argc != 3)
		return (ft_putstr("Error\n"), 1);
	path = "numbers.dict";
	number = argv[1];
	if (argc == 3)
	{
		path = argv[1];
		number = argv[2];
	}
	if (!is_valid_number(number))
		return (ft_putstr("Error\n"), 1);
	dict.entries = 0;
	dict.size = 0;
	if (!load_dictionary(path, &dict))
		return (print_dict_error(&dict));
	number = skip_zeros(number);
	if (!convert_number(number, &dict, 0))
		return (print_dict_error(&dict));
	convert_number(number, &dict, 1);
	write(1, "\n", 1);
	free_dictionary(&dict);
	return (0);
}
