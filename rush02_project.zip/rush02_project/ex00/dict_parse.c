#include "rush02.h"

static int	count_entries(char *buffer)
{
	int	i;
	int	start;
	int	count;

	i = 0;
	count = 0;
	while (buffer[i])
	{
		start = i;
		while (buffer[i] && buffer[i] != '\n')
			i++;
		if (!line_is_empty(buffer, start, i))
			count++;
		if (buffer[i] == '\n')
			i++;
	}
	return (count);
}

static int	valid_value(char *buffer, int start, int end)
{
	while (start < end)
	{
		if (buffer[start] < 32 || buffer[start] > 126)
			return (0);
		start++;
	}
	return (1);
}

static int	parse_line(char *buffer, int start, int end, t_dict *dict)
{
	t_bounds	b;
	int			i;

	if (line_is_empty(buffer, start, end))
		return (1);
	b.key_start = start;
	i = start;
	if (i >= end || buffer[i] < '0' || buffer[i] > '9')
		return (0);
	while (i < end && buffer[i] >= '0' && buffer[i] <= '9')
		i++;
	b.key_end = i;
	while (i < end && is_blank(buffer[i]))
		i++;
	if (i >= end || buffer[i++] != ':')
		return (0);
	while (i < end && is_blank(buffer[i]))
		i++;
	b.value_start = i;
	b.value_end = end;
	while (b.value_end > i && is_blank(buffer[b.value_end - 1]))
		b.value_end--;
	if (b.value_start == b.value_end)
		return (0);
	if (!valid_value(buffer, b.value_start, b.value_end))
		return (0);
	return (store_entry(buffer, &b, dict));
}

static int	parse_all(char *buffer, t_dict *dict)
{
	int	i;
	int	start;

	i = 0;
	while (buffer[i])
	{
		start = i;
		while (buffer[i] && buffer[i] != '\n')
			i++;
		if (!parse_line(buffer, start, i, dict))
			return (0);
		if (buffer[i] == '\n')
			i++;
	}
	return (1);
}

int	parse_dictionary(char *buffer, t_dict *dict)
{
	int	count;

	count = count_entries(buffer);
	if (count == 0)
		return (0);
	dict->entries = malloc(sizeof(t_entry) * count);
	if (!dict->entries)
		return (0);
	dict->size = 0;
	if (!parse_all(buffer, dict))
	{
		free_dictionary(dict);
		return (0);
	}
	return (1);
}
