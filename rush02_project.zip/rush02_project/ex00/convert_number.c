#include "rush02.h"

int	convert_group(int number, t_output *out);
int	emit_scale(t_output *out, int group_index);
int	convert_under_100(int number, t_output *out);

static int	group_value(char *number, int start, int length)
{
	int	value;

	value = 0;
	while (length > 0)
	{
		value = value * 10 + number[start] - '0';
		start++;
		length--;
	}
	return (value);
}

static int	first_group_length(int length)
{
	if (length % 3 == 0)
		return (3);
	return (length % 3);
}

static int	convert_groups(char *number, int length, t_output *out)
{
	int	position;
	int	group_len;
	int	group_index;
	int	value;

	position = 0;
	group_len = first_group_length(length);
	while (position < length)
	{
		value = group_value(number, position, group_len);
		group_index = (length - position - group_len) / 3;
		if (value != 0 && !convert_group(value, out))
			return (0);
		if (value != 0 && !emit_scale(out, group_index))
			return (0);
		position += group_len;
		group_len = 3;
	}
	return (1);
}

int	convert_number(char *number, t_dict *dict, int print)
{
	t_output	out;
	int			length;

	out.dict = dict;
	out.first = 1;
	out.print = print;
	if (number[0] == '0' && number[1] == '\0')
		return (convert_under_100(0, &out));
	length = ft_strlen(number);
	return (convert_groups(number, length, &out));
}
