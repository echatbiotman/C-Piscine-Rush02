#include "rush02.h"

char	*dup_range(char *str, int start, int end)
{
	char	*copy;
	int		i;

	copy = malloc(end - start + 1);
	if (!copy)
		return (0);
	i = 0;
	while (start < end)
		copy[i++] = str[start++];
	copy[i] = '\0';
	return (copy);
}

int	line_is_empty(char *str, int start, int end)
{
	while (start < end)
	{
		if (!is_blank(str[start]))
			return (0);
		start++;
	}
	return (1);
}

int	key_exists(t_dict *dict, char *key)
{
	int	i;

	i = 0;
	while (i < dict->size)
	{
		if (ft_strcmp(dict->entries[i].key, key) == 0)
			return (1);
		i++;
	}
	return (0);
}
